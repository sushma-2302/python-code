## Mathamatical Calculatios of Two numbers 
number_1 = 5
number_2 = 2
print(number_1 + number_2) ## Adds two numbers
print(number_1 - number_2) ## Substraction of two numbers
print(number_1 * number_2) ## Multiplication of two numbers
print(number_1 / number_2) ## Division of two numbers 
print(number_1 % number_2) ## output will be remainder
## Relational Operators 
print(number_1 > number_2)
print(number_1 < number_2)
print(number_1 == number_2)
print("-"*70) 

## Converting Kilometers to Meters 
a = 1.2 
b = float(a)
result = b * 1000
result = int(result)
print("Output: " + str(result))
print("-"*70) 
## String Repetation 
print("Concept String Repetation Method")
name = "Sai" ## name Sai as input
print("Output: "+ name * 5) ## It repeats the name for 5 times

print("-"*70) 


## String Indexing 
print("Concept String Indexing")
name = "Rahul" ## Rahul name as Input
print("Output: " + name[3]) ## It prints letter u as output 
print("-"*70) 

## Reversing Digits 
print("Concept Reversing Digits")
digit = str(32)
first_digit = digit[0]
second_digit = digit[1]
reverse_digit = second_digit + first_digit
print("Output: " + str(reverse_digit))
print("-"*70) 

## Printing Half String 
string = "ZooZoo"
length = len(string) ## To find length of string we use len() Built-in function
half_string = string[:int(length/2)]
print("Output: "+half_string)
## checking half part of a string
a = "Repeat"
b = "pea"
integer = int(2)
length_b = len(b)+ integer
b_is_part_of_a = a[integer:length_b] ## String Slicing
print(b_is_part_of_a == b)

## Extended Slicing 
secret_message = "-R-a-m-u-"
print(secret_message[1:8:2])
print("-"*70) 

## Program that prints first and last charcters of a string and print * instead of Remaining Charcters 

a = "Sushma2329"
b = len(a)
first_letter = a[0]
last_letter = a[b-1]
length_of_the_mask = b-2
result = (first_letter  + "*" * length_of_the_mask + last_letter)
print("Output: " + str(result))
print("-"*70) 

## Printing Positive or Negative numbers using Conditional Statements 
a = int(2)
b = int(-5)
if a > b:
    print("Output: " + str(a))
    print("Positive Number")
else:
    print("Output: " + str(b))
    print("Negative Number")
print("-"*70) 

## Nested Conditions 
time = 12
is_a_greater = time >= 4 and time < 12
if is_a_greater:
    print("Good Morning")
else:
    is_b_greater = time >= 12 and time < 16
    if is_b_greater:
        print("Good Afternoon")
    else:
        is_c_greater = time >=16 and time < 20
        if is_c_greater:
            print("Good Evening")
        else:
            print("Good Night")
print("-"*70) 
## printing right angle triangle using While Loop
n = 5
counter = 0 
while counter < n:
    counter = counter + 1 
    print(str(counter)*counter)

print("-"*70) 
n = 6 
for i in range(0,n):
    stars = "* "*(n-i)
    spaces = " "*(2*(i))
    print(spaces + stars)
print("-"*70) 
## Printing Even Numbers  from 1 to 20 Using "for loop" 
print("Even Numbers")
n = 10
string = ""
for i in range(1,20):
    if (i%2 == 0):
        string = string + str(i) + " "
print("Output: "+ string)

## Printing Odd numbers using for loop
print("Odd Numbers")
n = 10
string = ""
for i in range(1,21):
    if (i%2 != 0):
        string = string + str(i) + " "
print("Output: "+ string)

## printing prime numbers
print("Prime Numbers")
n = 20
string = ""
for i in range(2,n+1):
    factors = 0 
    for j in range(2,i):
        if i % j == 0:
            factors = factors + 1 
    if factors == 0:
        string = string + str(i) + " "
print("Output: "+ str(string))
print("-"*70) 

## Printing Butterfly Pattern 
n = 4
for i in range(1,n+1):
    stars = "* "* i
    middle_spaces = "  "*(2*(n-i))
    print(stars+middle_spaces+stars)
    
for i in range(n):
    stars="* " * (n-i)
    middle_spaces = "  "*(2*i)
    print(stars+middle_spaces+stars)
print("-"*70)  
## printing hollow diamond
n = 7
for i in range(1,n+1):
    spaces = " "*(n-i)
    stars ="* "*i
    print(spaces+stars+spaces)
for i in range(1,n):
    spaces = " "*(i)
    if i == n-1:
        stars ="* "
        print(spaces+stars+spaces)
    else:
        hollow_spaces = " "*((2*n-1)-(2*i+2))
        print(spaces+"*"+hollow_spaces+"*"+spaces)
print("-"*70)  


## String Methods  
string = "sushma   "
print("Output: " + string.upper()) ## Converts string into Upper Case
print("Output: " +string.lower()) ## Converts string into lower letter
print("Output: " + string.strip()) ## Removing lead or trailing spaces 

string  = "http://latha@google.cam"
print(string.replace("cam","com"))
print(string.startswith("http"))
print(string.endswith("@google.cam"))
print("-"*70)  

s = "egami"
length = len(s)
shaffule = ""
string = ""
for i in range (length):
    shaffule = s[i] + shaffule
print(shaffule)
print("-"*70) 
## 

## printing Capital and small letters. 
string = ""
for i in range(65,91):
    string = string + str(chr(i)) + " "
print(string)

string = ""
for i in range(97,123):
    string = string + str(chr(i)) + " "
print(string)
print("-"*70) 
## printing numbers 
for i in range(48,58):
    print(chr(i))
print("-"*70) 

## Lists 
a = [2,"suma",5.6,8]
for i in a:
    print(i)
print("index:1 have a name " + str(a[1]))
print("-"*70)
## printing word triangle 
n = "sushma"
s = len(n)
for i in range(1,s+1):
    print(n[:i])
print("-"*70)
## Amstrong Numbers from 1 to 153
n = 153
for i in range(1,n+1):
    length = len(str(i))
    sum = 0 
    b = str(i)
    for j in b:
        sum = sum + int(j)**length
    if sum == i:
        print(i)
print("-"*70)
## Palindrome 
print("Checking given string is palindrome or not")
string = "Madam"
string = string.lower()
reverse = ""
for i in string:
    reverse = str(i) + reverse 
if string == reverse:
    print("palindrome")
else:
    print("Not palindrome")
print("-" * 30)
string = "Ramana"
string = string.lower()
reverse = ""
for i in string:
    reverse = str(i) + reverse 
if string == reverse:
    print("palindrome")
else:
    print("Not palindrome")
print("-"*70)